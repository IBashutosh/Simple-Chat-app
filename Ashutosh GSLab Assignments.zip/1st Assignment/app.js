const readline = require("readline");
let fs = require("fs");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

var recursiveAsyncReadLine = function () {
  let obj = new HashTableChains();
  fs.readFile("./string.txt", "utf8", function (err, data) {
    if (err) throw err;
    obj.put(data);
    rl.question('Search String: ', function (answer) {
      if (answer == 'exit')
        return rl.close();
      console.log(obj.get(answer));
      obj = null;
      recursiveAsyncReadLine();
    });
  });
};

recursiveAsyncReadLine();

rl.on("close", function () {
  console.log("\nBYE BYE !!!");
  process.exit(0);
});

function HashTableChains() {
  this.stringArray = [];
  this.hasArray = [];
}

HashTableChains.prototype.put = function (fileStringData) {
  this.stringArray = fileStringData.replace(/\"/g, "").split("\r\n");
  let fileHashData = this.stringArray.map((element) => Math.floor(
    (((((element.charCodeAt() * 100) / 4) * 2.5) / 6) * 9) %
    this.stringArray.length
  ));
  for (let strIndex = 0; strIndex < fileHashData.length; strIndex++) {
    if (!this.hasArray[fileHashData[strIndex]]) {
      this.hasArray[fileHashData[strIndex]] = [];
    }
    this.hasArray[fileHashData[strIndex]].push(this.stringArray[strIndex]);
  }
}

HashTableChains.prototype.get = function (str) {
  let hashIndex = Math.floor(
    (((((str.charCodeAt() * 100) / 4) * 2.5) / 6) * 9) % this.stringArray.length
  );

  if (this.hasArray[hashIndex].includes(str)) {
    return true;
  } else {
    return false;
  }
}

