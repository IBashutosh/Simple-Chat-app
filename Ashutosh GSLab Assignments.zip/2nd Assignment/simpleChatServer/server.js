const express = require("express");
const app = express();

const http = require("http");
const server = http.Server(app);

const socketIO = require("socket.io");
const io = socketIO(server);

const port = process.env.PORT || 3000;

const allUsers = [];
let fs = require("fs");
const crypto = require("crypto");

io.on("connection", (socket) => {
  allUsers.push(socket);

  io.emit("user-join", allUsers.length);

  socket.on("user-message", (message) => {
    io.emit("user-message", message);
  });

  socket.on("disconnect", (message) => {
    const i = allUsers.indexOf(socket);
    allUsers.splice(i, 1);
    io.emit("user-discon", allUsers.length);
  });
});

server.listen(port, () => {
    console.log(`started on port: ${port}`);
  });