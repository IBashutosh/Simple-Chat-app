import { Component, OnInit } from '@angular/core';
import { ChatService } from './services/chat.service';
import { Subscription } from 'rxjs';
import { Message } from './model/message/message.module';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  newMessage: string;
  messageList: Message[] = [];
  getMessagesSubscr: Subscription;
  onlineUserCount: number;
  updateUserCountSubscr: Subscription;

  constructor(public chatService: ChatService) {}

  /**
   * send message to users
   */
  sendMessage() {
    this.chatService.sendMessage(this.newMessage);
    this.newMessage = '';
    this.chatService.isSender = true;
  }

  ngOnInit() {
    this.getMessagesSubscriptition();
    this.updateUserCount();
  }

  /**
   * update message list when new message came from server
   */
  getMessagesSubscriptition() {
    this.getMessagesSubscr = this.chatService.getMessages$.subscribe(
      (message: Message) => {
        if (message) {
          this.messageList.push(message);
          setTimeout(() => {
            const elem = document.getElementById('mainDiv');
            elem.scrollTop = elem.scrollHeight;
          });
        }
      }
    );
  }

  /**
   * update user count
   */
  updateUserCount() {
    this.updateUserCountSubscr = this.chatService.updateUserCount$.subscribe(
      (count: number) => {
        if (count) {
          this.onlineUserCount = count;
        }
      }
    );
  }

  ngOnDestroy() {
    if (this.getMessagesSubscr) {
      this.getMessagesSubscr.unsubscribe();
    }
    if (this.updateUserCountSubscr) {
      this.updateUserCountSubscr.unsubscribe();
    }
  }
}
