export interface Message {
  message: string;
  time: Date;
  isSender: boolean;
}
