import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Subject } from 'rxjs';
import { Message } from '../model/message/message.module';
@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private url = 'http://localhost:3000';
  private socket;
  onlineUserCount;
  isSender: boolean;
  getMessages = new Subject<Message>();
  getMessages$ = this.getMessages.asObservable();

  connectedUsers = new Subject<Message>();
  connectedUsers$ = this.connectedUsers.asObservable();

  updateUserCount = new Subject<number>();
  updateUserCount$ = this.updateUserCount.asObservable();

  constructor() {
    this.socket = io(this.url);
    this.getMessagesFromServer();
    this.onUserConnect();
    this.onUserDisconnect();
  }

  /**
   * emit messege to server socket
   */
  public sendMessage(message) {
    this.socket.emit('user-message', message);
  }

  /**
   * update user count when new user connect
   */
  public onUserConnect() {
    this.socket.on('user-join', (userCount) => {
      this.updateUserCount.next(userCount);
    });
  }

  /**
   * update user count when user disconnect
   */
  public onUserDisconnect() {
    this.socket.on('user-discon', (userCount) => {
      this.updateUserCount.next(userCount);
    });
  }

  /**
   * play audio when new message came
   */
  playAudio() {
    const audio = new Audio();
    audio.src =
      'https://notificationsounds.com/soundfiles/ef575e8837d065a1683c022d2077d342/file-sounds-713-beep.mp3';
    audio.load();
    audio.play();
  }

  /**
   * subscription to socket for new mesages
   */
  public getMessagesFromServer() {
    this.socket.on('user-message', (message) => {
      const date = new Date();
      let serverMsg: Message;
      if (this.isSender === true) {
        serverMsg = {
          message: message,
          time: date,
          isSender: true,
        };
      } else {
        serverMsg = {
          message: message,
          time: date,
          isSender: false,
        };
        this.playAudio();
      }

      this.getMessages.next(serverMsg);
      this.isSender = false;
    });
  }
}
